module.exports = function(settings, headers) {

    return {
        title: "Resultado",
        Module: "Result Module 4",
        text1:"Decision number selected for payment: ",
        text2:"Your decision: ",
        text3:"Profit of the module: $",
        proceed:"Continue"
    };
};
/**
 * Created by joseorellana on 07-02-16.
 */
