module.exports = function(settings, headers) {

    return {
        title: "Resultado",
        Module: "Result Module 2",
        text1:"Selected round for payment: ",
        text2:"Number of correct answers: ",
        text3:"Preliminary earnings: ",
        text4:"Declared earnings: ",
        text5:"Total deductions: ",
        text6:"Amount received from pooled deduction:",
        text7:"Profit of this round: ",
        proceed:"Continue"
    };
};
/**
 * Created by joseorellana on 07-02-16.
 * Aki translated on 18-02-16
 */
