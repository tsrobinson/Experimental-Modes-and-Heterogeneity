module.exports = function(settings, headers) {

    return {
        title: "Resultado",
        module: "Result Module 1",
        text1:"You are in group ",
        text2:"Amount",
        text3:"Total profit: ",
        proceed:"Continue"
    };
};
/**
 * Created by joseorellana on 07-02-16.
 */
