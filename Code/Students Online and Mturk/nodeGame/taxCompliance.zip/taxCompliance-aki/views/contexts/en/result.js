module.exports = function(settings, headers) {

    return {
        title: "Resultado",
        Module: "Result of the round",
        text1:"Number of correct answers:",
        text2:"Preliminary earnings:",
        text3:"Declared earnings:",
        text4:"Total deduction:",
        text5:"Earnings after deduction:",
        text6:"Amount received from pooled deduction:",
        text7:"Profit of this round: ",
        proceed:"Continue"
    };
};/**
 * Created by joseorellana on 08-01-16.
 * Back translated by amatz on 15-02-16.
 */
