module.exports = function(settings, headers) {

    return {
        title: "Declaration",
        Module: "Declaration",
        text1:"Number of correct answers: ",
        text2:"Total earnings: ",
        text3:"Amount to declare: ",
        proceed:"Declare",
        error:"Enter a value between 0 and ",
        errorClose: "Close",
    };
};

/**
 * Created by joseorellana on 06-01-16.
 */
