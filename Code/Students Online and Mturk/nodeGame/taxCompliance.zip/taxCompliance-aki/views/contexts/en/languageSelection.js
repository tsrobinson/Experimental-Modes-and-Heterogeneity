module.exports = function(settings, headers) {
    return { title: "Instructions" };
};
